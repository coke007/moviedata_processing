环境：Anaconda2019集成环境下的jupyter Notebook（数据分析常用软件）
语言：python 
运行结果+代码展示：dataProcessing - Jupyter Notebook.html
源代码：dataProcessing.ipynb  （不是浏览器直接打开）